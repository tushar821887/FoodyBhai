import { HydratedDocument } from 'mongoose';
export type ContactDocument = HydratedDocument<Contact>;
export declare class Contact {
    name: string;
    email: string;
    phone: string;
    message: string;
}
export declare const ContactSchema: import("mongoose").Schema<Contact, import("mongoose").Model<Contact, any, any, any, import("mongoose").Document<unknown, any, Contact, any, {}> & Contact & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Contact, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Contact>, {}, import("mongoose").DefaultSchemaOptions> & import("mongoose").FlatRecord<Contact> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
