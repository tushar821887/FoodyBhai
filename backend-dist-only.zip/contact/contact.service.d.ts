import { Model } from 'mongoose';
import { ContactDocument } from './schemas/contact.schema';
export declare class ContactService {
    private contactModel;
    constructor(contactModel: Model<ContactDocument>);
    create(contactData: any): Promise<ContactDocument>;
    findAll(): Promise<ContactDocument[]>;
}
