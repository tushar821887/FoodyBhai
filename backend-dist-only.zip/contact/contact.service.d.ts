import { Model } from 'mongoose';
import { ContactDocument } from './schemas/contact.schema';
import { SettingsService } from '../settings/settings.service';
export declare class ContactService {
    private contactModel;
    private readonly settingsService;
    private readonly logger;
    constructor(contactModel: Model<ContactDocument>, settingsService: SettingsService);
    create(contactData: any): Promise<ContactDocument>;
    findAll(): Promise<ContactDocument[]>;
    private sendNotificationEmails;
}
