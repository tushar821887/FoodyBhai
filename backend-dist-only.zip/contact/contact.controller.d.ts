import { ContactService } from './contact.service';
export declare class ContactController {
    private readonly contactService;
    constructor(contactService: ContactService);
    createMessage(body: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/contact.schema").Contact, {}, {}> & import("./schemas/contact.schema").Contact & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    getAllMessages(): Promise<(import("mongoose").Document<unknown, {}, import("./schemas/contact.schema").Contact, {}, {}> & import("./schemas/contact.schema").Contact & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
}
