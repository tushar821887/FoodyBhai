export declare class AgentsModule {
}
