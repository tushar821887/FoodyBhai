import { RecipesService } from './recipes.service';
export declare class RecipesController {
    private readonly recipesService;
    constructor(recipesService: RecipesService);
    getAll(): Promise<(import("mongoose").Document<unknown, {}, import("./schemas/recipe.schema").Recipe, {}, {}> & import("./schemas/recipe.schema").Recipe & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    getBySlug(slug: string): Promise<import("mongoose").Document<unknown, {}, import("./schemas/recipe.schema").Recipe, {}, {}> & import("./schemas/recipe.schema").Recipe & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    create(req: any, data: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/recipe.schema").Recipe, {}, {}> & import("./schemas/recipe.schema").Recipe & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    update(req: any, id: string, data: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/recipe.schema").Recipe, {}, {}> & import("./schemas/recipe.schema").Recipe & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    remove(req: any, id: string): Promise<any>;
    toggleStock(id: string, inStock?: boolean): Promise<import("mongoose").Document<unknown, {}, import("./schemas/recipe.schema").Recipe, {}, {}> & import("./schemas/recipe.schema").Recipe & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}
