import { HydratedDocument } from 'mongoose';
export type RecipeDocument = HydratedDocument<Recipe>;
export declare class Recipe {
    id: number;
    slug: string;
    title: string;
    description: string;
    introduction: string;
    category: string;
    cuisine: string;
    prepTime: string;
    cookTime: string;
    totalTime: string;
    servings: number;
    difficulty: string;
    ingredients: string[];
    instructions: string[];
    tips: string[];
    image: string;
    imageAlt: string;
    seoTitle: string;
    seoDescription: string;
    isVeg: boolean;
    inStock: boolean;
    price: number;
    recipeHtml?: string;
}
export declare const RecipeSchema: import("mongoose").Schema<Recipe, import("mongoose").Model<Recipe, any, any, any, import("mongoose").Document<unknown, any, Recipe, any, {}> & Recipe & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Recipe, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Recipe>, {}, import("mongoose").DefaultSchemaOptions> & import("mongoose").FlatRecord<Recipe> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
