export declare class RecipesModule {
}
