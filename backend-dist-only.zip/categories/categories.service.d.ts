import { Model } from 'mongoose';
import { CategoryDocument } from './schemas/category.schema';
export declare class CategoriesService {
    private categoryModel;
    constructor(categoryModel: Model<CategoryDocument>);
    findAll(): Promise<CategoryDocument[]>;
    create(data: any): Promise<CategoryDocument | null>;
    update(id: string, data: any): Promise<CategoryDocument | null>;
    remove(id: string): Promise<any>;
}
