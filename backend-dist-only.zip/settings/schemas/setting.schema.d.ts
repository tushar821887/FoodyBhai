import { HydratedDocument } from 'mongoose';
export type SettingDocument = HydratedDocument<Setting>;
export declare class Setting {
    key: string;
    value: any;
}
export declare const SettingSchema: import("mongoose").Schema<Setting, import("mongoose").Model<Setting, any, any, any, import("mongoose").Document<unknown, any, Setting, any, {}> & Setting & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Setting, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Setting>, {}, import("mongoose").DefaultSchemaOptions> & import("mongoose").FlatRecord<Setting> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
