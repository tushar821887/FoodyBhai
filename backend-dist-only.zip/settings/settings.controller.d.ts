import { SettingsService } from './settings.service';
export declare class SettingsController {
    private readonly settingsService;
    constructor(settingsService: SettingsService);
    getAllSettings(): Promise<any>;
    getLatestAppInfo(): Promise<{
        version: any;
        downloadUrl: any;
        releaseNotes: any;
    }>;
    downloadApkDirect(res: any): any;
    uploadApk(file: any, body: any): Promise<{
        success: boolean;
        message: string;
        version: string;
        size: any;
        downloadUrl: string;
    }>;
    testSmtpConnection(body: any): Promise<{
        success: boolean;
        message: string;
        messageId: any;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        message?: undefined;
        messageId?: undefined;
    }>;
    getSetting(key: string): Promise<{
        value: any;
    }>;
    setSetting(key: string, body: any): Promise<void>;
}
