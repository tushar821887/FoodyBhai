"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const settings_service_1 = require("./settings.service");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let SettingsController = class SettingsController {
    constructor(settingsService) {
        this.settingsService = settingsService;
    }
    getAllSettings() {
        return this.settingsService.getAllSettings();
    }
    async getLatestAppInfo() {
        const version = await this.settingsService.getSetting('app_version');
        const downloadUrl = await this.settingsService.getSetting('app_download_url');
        const releaseNotes = await this.settingsService.getSetting('app_release_notes');
        return {
            version: version || '1.0.0',
            downloadUrl: downloadUrl || '/downloads/foodybhai.apk',
            releaseNotes: releaseNotes || 'Real-time order alerts, smoother performance, and instant order tracking.'
        };
    }
    downloadApkDirect(res) {
        const candidates = [
            path.resolve(__dirname, '../../../frontend/public/downloads/foodybhai.apk'),
            path.resolve(__dirname, '../../../frontend/dist/foody-bhai/browser/downloads/foodybhai.apk'),
            path.resolve(__dirname, '../../../../frontend/public/downloads/foodybhai.apk'),
            path.resolve(__dirname, '../../../../frontend/dist/foody-bhai/browser/downloads/foodybhai.apk'),
            path.resolve(process.cwd(), 'uploads/foodybhai.apk'),
            path.resolve(process.cwd(), '../frontend/public/downloads/foodybhai.apk'),
            path.resolve(process.cwd(), '../frontend/dist/foody-bhai/browser/downloads/foodybhai.apk'),
        ];
        for (const p of candidates) {
            if (fs.existsSync(p) && fs.statSync(p).size > 100000) {
                res.setHeader('Content-Type', 'application/vnd.android.package-archive');
                res.setHeader('Content-Disposition', 'attachment; filename="FoodyBhai.apk"');
                return fs.createReadStream(p).pipe(res);
            }
        }
        return res.status(404).json({ error: 'APK file not found on server' });
    }
    async uploadApk(file, body) {
        if (!file) {
            throw new common_1.BadRequestException('No APK file provided.');
        }
        const destinations = [
            path.resolve(__dirname, '../../../frontend/public/downloads/foodybhai.apk'),
            path.resolve(__dirname, '../../../frontend/dist/foody-bhai/browser/downloads/foodybhai.apk'),
            path.resolve(__dirname, '../../../../frontend/public/downloads/foodybhai.apk'),
            path.resolve(__dirname, '../../../../frontend/dist/foody-bhai/browser/downloads/foodybhai.apk'),
            path.resolve(process.cwd(), 'uploads/foodybhai.apk'),
            path.resolve(process.cwd(), '../frontend/public/downloads/foodybhai.apk'),
            path.resolve(process.cwd(), '../frontend/dist/foody-bhai/browser/downloads/foodybhai.apk'),
        ];
        for (const dest of destinations) {
            try {
                const dir = path.dirname(dest);
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir, { recursive: true });
                }
                fs.writeFileSync(dest, file.buffer);
            }
            catch (e) { }
        }
        if (body && body.version) {
            await this.settingsService.setSetting('app_version', body.version);
        }
        if (body && body.releaseNotes) {
            await this.settingsService.setSetting('app_release_notes', body.releaseNotes);
        }
        await this.settingsService.setSetting('app_download_url', '/downloads/foodybhai.apk');
        const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
        return {
            success: true,
            message: `APK uploaded successfully (${sizeMb} MB)!`,
            size: file.size,
            downloadUrl: '/downloads/foodybhai.apk'
        };
    }
    async getSetting(key) {
        const value = await this.settingsService.getSetting(key);
        return { value };
    }
    setSetting(key, body) {
        return this.settingsService.setSetting(key, body.value);
    }
};
exports.SettingsController = SettingsController;
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "getAllSettings", null);
__decorate([
    (0, common_1.Get)('app/latest'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SettingsController.prototype, "getLatestAppInfo", null);
__decorate([
    (0, common_1.Get)('app/download'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "downloadApkDirect", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)('app/upload-apk'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('apk')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], SettingsController.prototype, "uploadApk", null);
__decorate([
    (0, common_1.Get)(':key'),
    __param(0, (0, common_1.Param)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SettingsController.prototype, "getSetting", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Put)(':key'),
    __param(0, (0, common_1.Param)('key')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], SettingsController.prototype, "setSetting", null);
exports.SettingsController = SettingsController = __decorate([
    (0, common_1.Controller)('settings'),
    __metadata("design:paramtypes", [settings_service_1.SettingsService])
], SettingsController);
//# sourceMappingURL=settings.controller.js.map