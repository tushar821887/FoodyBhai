import { Model } from 'mongoose';
import { SettingDocument } from './schemas/setting.schema';
export declare class SettingsService {
    private settingModel;
    constructor(settingModel: Model<SettingDocument>);
    getSetting(key: string): Promise<any>;
    setSetting(key: string, value: any): Promise<void>;
    getAllSettings(): Promise<any>;
}
