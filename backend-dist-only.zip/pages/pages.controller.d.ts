import { PagesService } from './pages.service';
export declare class PagesController {
    private readonly pagesService;
    constructor(pagesService: PagesService);
    findAll(): Promise<import("./schemas/page.schema").Page[]>;
    findBySlugQuery(slug: string): Promise<import("./schemas/page.schema").Page>;
    findBySlug(slug: string): Promise<import("./schemas/page.schema").Page>;
    create(pageData: any): Promise<import("./schemas/page.schema").Page>;
    bulkSave(pages: any[]): Promise<import("./schemas/page.schema").Page[]>;
    updateBySlug(slug: string, pageData: any): Promise<import("./schemas/page.schema").Page | null>;
    update(id: string, pageData: any): Promise<import("./schemas/page.schema").Page | null>;
    deleteBySlug(slug: string): Promise<any>;
    delete(id: string): Promise<any>;
}
