import { OnModuleInit } from '@nestjs/common';
import { Model } from 'mongoose';
import { Page, PageDocument } from './schemas/page.schema';
export declare class PagesService implements OnModuleInit {
    private pageModel;
    private readonly logger;
    constructor(pageModel: Model<PageDocument>);
    onModuleInit(): Promise<void>;
    findAll(): Promise<Page[]>;
    findBySlug(slug: string): Promise<Page | null>;
    create(pageData: Partial<Page>): Promise<Page>;
    update(slug: string, pageData: Partial<Page>): Promise<Page | null>;
    bulkSave(pages: Partial<Page>[]): Promise<Page[]>;
    remove(slug: string): Promise<any>;
    private seedInitialPagesIfEmpty;
}
