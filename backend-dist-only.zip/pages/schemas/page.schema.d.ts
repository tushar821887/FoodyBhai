import { HydratedDocument } from 'mongoose';
export type PageDocument = HydratedDocument<Page>;
export declare class SectionItem {
    id?: string;
    icon?: string;
    title?: string;
    subtitle?: string;
    description?: string;
    link?: string;
    imageUrl?: string;
    rating?: number;
    author?: string;
    role?: string;
    price?: number;
}
export declare class SectionStyle {
    paddingTop?: string;
    paddingBottom?: string;
    maxWidth?: string;
    minHeight?: string;
    backgroundColor?: string;
    backgroundGradient?: string;
    backgroundImage?: string;
    textColor?: string;
    titleFontSize?: string;
    contentFontSize?: string;
    textAlign?: string;
    borderRadius?: string;
    gridColumns?: number;
    gridGap?: string;
}
export declare class PageSection {
    id: string;
    type: string;
    title?: string;
    subtitle?: string;
    content?: string;
    badge?: string;
    buttonText?: string;
    buttonLink?: string;
    secondaryButtonText?: string;
    secondaryButtonLink?: string;
    imageUrl?: string;
    imagePosition?: string;
    items?: SectionItem[];
    rawHtml?: string;
    style: SectionStyle;
    isEnabled: boolean;
}
export declare class Page {
    slug: string;
    title: string;
    metaDescription: string;
    isCustomRoute: boolean;
    isEnabled: boolean;
    order: number;
    sections: PageSection[];
}
export declare const PageSchema: import("mongoose").Schema<Page, import("mongoose").Model<Page, any, any, any, import("mongoose").Document<unknown, any, Page, any, {}> & Page & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Page, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Page>, {}, import("mongoose").DefaultSchemaOptions> & import("mongoose").FlatRecord<Page> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
