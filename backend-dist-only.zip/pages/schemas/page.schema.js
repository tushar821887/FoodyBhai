"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PageSchema = exports.Page = exports.PageSection = exports.SectionStyle = exports.SectionItem = void 0;
const mongoose_1 = require("@nestjs/mongoose");
let SectionItem = class SectionItem {
};
exports.SectionItem = SectionItem;
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "id", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "icon", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "subtitle", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "description", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "link", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "imageUrl", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Number)
], SectionItem.prototype, "rating", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "author", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionItem.prototype, "role", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Number)
], SectionItem.prototype, "price", void 0);
exports.SectionItem = SectionItem = __decorate([
    (0, mongoose_1.Schema)({ _id: false })
], SectionItem);
let SectionStyle = class SectionStyle {
};
exports.SectionStyle = SectionStyle;
__decorate([
    (0, mongoose_1.Prop)({ default: '60px' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "paddingTop", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '60px' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "paddingBottom", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '1200px' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "maxWidth", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionStyle.prototype, "minHeight", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 'transparent' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "backgroundColor", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionStyle.prototype, "backgroundGradient", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionStyle.prototype, "backgroundImage", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], SectionStyle.prototype, "textColor", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '36px' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "titleFontSize", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '16px' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "contentFontSize", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 'left' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "textAlign", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '0px' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "borderRadius", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 3 }),
    __metadata("design:type", Number)
], SectionStyle.prototype, "gridColumns", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '24px' }),
    __metadata("design:type", String)
], SectionStyle.prototype, "gridGap", void 0);
exports.SectionStyle = SectionStyle = __decorate([
    (0, mongoose_1.Schema)({ _id: false })
], SectionStyle);
let PageSection = class PageSection {
};
exports.PageSection = PageSection;
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], PageSection.prototype, "id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], PageSection.prototype, "type", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "subtitle", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "content", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "badge", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "buttonText", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "buttonLink", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "secondaryButtonText", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "secondaryButtonLink", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "imageUrl", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 'right' }),
    __metadata("design:type", String)
], PageSection.prototype, "imagePosition", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [SectionItem], default: [] }),
    __metadata("design:type", Array)
], PageSection.prototype, "items", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], PageSection.prototype, "rawHtml", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: SectionStyle, default: () => ({}) }),
    __metadata("design:type", SectionStyle)
], PageSection.prototype, "style", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: true }),
    __metadata("design:type", Boolean)
], PageSection.prototype, "isEnabled", void 0);
exports.PageSection = PageSection = __decorate([
    (0, mongoose_1.Schema)({ _id: false })
], PageSection);
let Page = class Page {
};
exports.Page = Page;
__decorate([
    (0, mongoose_1.Prop)({ required: true, unique: true }),
    __metadata("design:type", String)
], Page.prototype, "slug", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], Page.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    __metadata("design:type", String)
], Page.prototype, "metaDescription", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: false }),
    __metadata("design:type", Boolean)
], Page.prototype, "isCustomRoute", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: true }),
    __metadata("design:type", Boolean)
], Page.prototype, "isEnabled", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 0 }),
    __metadata("design:type", Number)
], Page.prototype, "order", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [PageSection], default: [] }),
    __metadata("design:type", Array)
], Page.prototype, "sections", void 0);
exports.Page = Page = __decorate([
    (0, mongoose_1.Schema)({ timestamps: true, collection: 'pages' })
], Page);
exports.PageSchema = mongoose_1.SchemaFactory.createForClass(Page);
//# sourceMappingURL=page.schema.js.map