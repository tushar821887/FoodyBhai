export declare class PagesModule {
}
