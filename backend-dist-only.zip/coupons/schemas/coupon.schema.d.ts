import { HydratedDocument } from 'mongoose';
export type CouponDocument = HydratedDocument<Coupon>;
export declare class Coupon {
    code: string;
    description: string;
    discountType: 'percentage' | 'fixed';
    discountValue: number;
    minOrderAmount: number;
    maxDiscount?: number;
    validFrom: Date;
    validUntil?: Date;
    usageLimit?: number;
    perUserLimit?: number;
    usedCount: number;
    isActive: boolean;
    isPublic: boolean;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const CouponSchema: import("mongoose").Schema<Coupon, import("mongoose").Model<Coupon, any, any, any, import("mongoose").Document<unknown, any, Coupon, any, {}> & Coupon & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Coupon, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Coupon>, {}, import("mongoose").DefaultSchemaOptions> & import("mongoose").FlatRecord<Coupon> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
