import { Model } from 'mongoose';
import { CouponDocument } from './schemas/coupon.schema';
import { OrderDocument } from '../orders/schemas/order.schema';
export declare class CouponsService {
    private couponModel;
    private orderModel;
    constructor(couponModel: Model<CouponDocument>, orderModel: Model<OrderDocument>);
    create(createDto: any): Promise<CouponDocument>;
    findAll(): Promise<any[]>;
    getStats(): Promise<any>;
    getCouponOrders(code?: string): Promise<any[]>;
    validateCoupon(code: string, orderAmount: number, userId?: string): Promise<any>;
    getActivePublicCoupons(): Promise<any[]>;
    update(id: string, updateDto: any): Promise<CouponDocument>;
    remove(id: string): Promise<any>;
    recordUsage(code: string): Promise<void>;
}
