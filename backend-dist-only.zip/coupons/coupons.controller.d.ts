import { CouponsService } from './coupons.service';
export declare class CouponsController {
    private readonly couponsService;
    constructor(couponsService: CouponsService);
    getStats(): Promise<any>;
    getCouponOrders(code?: string): Promise<any[]>;
    getActivePublicCoupons(): Promise<any[]>;
    validateCoupon(code: string, orderAmount: number, userId?: string): Promise<any>;
    findAll(): Promise<any[]>;
    create(createDto: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/coupon.schema").Coupon, {}, {}> & import("./schemas/coupon.schema").Coupon & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    update(id: string, updateDto: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/coupon.schema").Coupon, {}, {}> & import("./schemas/coupon.schema").Coupon & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    remove(id: string): Promise<any>;
}
