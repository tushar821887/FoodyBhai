import { Model } from 'mongoose';
import { UserDocument } from './schemas/user.schema';
export declare class UsersService {
    private userModel;
    private readonly logger;
    constructor(userModel: Model<UserDocument>);
    cleanPhone(raw: string): string;
    createUser(name: string, email: string, password: string, phone?: string, role?: string): Promise<UserDocument>;
    findByEmail(email: string): Promise<UserDocument | null>;
    findByPhone(phone: string): Promise<UserDocument | null>;
    findByEmailOrPhone(identifier: string): Promise<UserDocument | null>;
    createGuestUser(name: string, phone: string, email?: string, address?: string): Promise<UserDocument>;
    setPassword(userId: string, newPassword: string): Promise<UserDocument | null>;
    findById(id: string): Promise<UserDocument | null>;
    validatePassword(plainPassword: string, hashedPassword: string): Promise<boolean>;
    findAll(): Promise<UserDocument[]>;
    updateUser(id: string, updateData: any): Promise<UserDocument | null>;
    deleteUser(id: string): Promise<any>;
    addAddress(userId: string, addressData: {
        label: string;
        fullAddress: string;
    }): Promise<UserDocument | null>;
    deleteAddress(userId: string, addressId: string): Promise<UserDocument | null>;
}
