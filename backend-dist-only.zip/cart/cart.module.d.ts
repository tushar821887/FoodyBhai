export declare class CartModule {
}
