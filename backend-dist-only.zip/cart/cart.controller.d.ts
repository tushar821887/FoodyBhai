import { CartService } from './cart.service';
export declare class CartController {
    private readonly cartService;
    constructor(cartService: CartService);
    getCart(req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/cart.schema").Cart, {}, {}> & import("./schemas/cart.schema").Cart & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    updateCart(req: any, items: any[]): Promise<import("mongoose").Document<unknown, {}, import("./schemas/cart.schema").Cart, {}, {}> & import("./schemas/cart.schema").Cart & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}
