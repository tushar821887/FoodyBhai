import { Model } from 'mongoose';
import { CartDocument } from './schemas/cart.schema';
export declare class CartService {
    private cartModel;
    constructor(cartModel: Model<CartDocument>);
    getCart(userId: string): Promise<CartDocument>;
    updateCart(userId: string, items: any[]): Promise<CartDocument>;
}
