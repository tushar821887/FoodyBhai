import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../users/users.service';
import { AgentsService } from '../agents/agents.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { SettingsService } from '../settings/settings.service';
export declare class AuthService {
    private readonly usersService;
    private readonly agentsService;
    private readonly jwtService;
    private readonly settingsService;
    private readonly logger;
    constructor(usersService: UsersService, agentsService: AgentsService, jwtService: JwtService, settingsService: SettingsService);
    generateTokenForUser(user: any): string;
    register(registerDto: RegisterDto): Promise<{
        success: boolean;
        message: string;
        user: {
            id: string;
            name: string;
            email: string;
            phone: string;
            role: string;
            needsPasswordSet: boolean;
        };
    }>;
    login(loginDto: LoginDto): Promise<{
        success: boolean;
        message: string;
        accessToken: string;
        user: {
            id: string | null;
            name: string | null;
            email: string;
            role: string | null;
            phone: string | null;
            needsPasswordSet: boolean;
        };
    }>;
    guestSetPassword(identifier: string, newPassword: string): Promise<{
        success: boolean;
        message: string;
        accessToken: string;
        user: {
            id: string;
            name: string;
            email: string;
            role: string;
            phone: string;
            needsPasswordSet: boolean;
        };
    }>;
    private maskEmail;
    private maskPhone;
    sendForgotPasswordOtp(identifier: string): Promise<{
        success: boolean;
        message: string;
        maskedEmail: string;
        maskedPhone: string;
    }>;
    verifyForgotPasswordOtp(identifier: string, otp: string): Promise<{
        success: boolean;
        message: string;
        resetToken: string;
    }>;
    resetPasswordWithToken(identifier: string, resetToken: string, newPassword: string): Promise<{
        success: boolean;
        message: string;
        accessToken: string;
        user: {
            id: string;
            name: string;
            email: string;
            phone: string;
            role: string;
            needsPasswordSet: boolean;
        };
    }>;
}
