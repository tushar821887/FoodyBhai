import { AuthService } from './auth.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    register(registerDto: RegisterDto): Promise<{
        success: boolean;
        message: string;
        user: {
            id: string;
            name: string;
            email: string;
            phone: string;
            role: string;
            needsPasswordSet: boolean;
        };
    }>;
    login(loginDto: LoginDto): Promise<{
        success: boolean;
        message: string;
        accessToken: string;
        user: {
            id: string | null;
            name: string | null;
            email: string;
            role: string | null;
            phone: string | null;
            needsPasswordSet: boolean;
        };
    }>;
    guestSetPassword(body: {
        identifier: string;
        password: string;
    }): Promise<{
        success: boolean;
        message: string;
        accessToken: string;
        user: {
            id: string;
            name: string;
            email: string;
            role: string;
            phone: string;
            needsPasswordSet: boolean;
        };
    }>;
    sendForgotPasswordOtp(body: {
        identifier: string;
    }): Promise<{
        success: boolean;
        message: string;
        maskedEmail: string;
        maskedPhone: string;
    }>;
    verifyForgotPasswordOtp(body: {
        identifier: string;
        otp: string;
    }): Promise<{
        success: boolean;
        message: string;
        resetToken: string;
    }>;
    resetPasswordWithToken(body: {
        identifier: string;
        resetToken: string;
        newPassword: string;
    }): Promise<{
        success: boolean;
        message: string;
        accessToken: string;
        user: {
            id: string;
            name: string;
            email: string;
            phone: string;
            role: string;
            needsPasswordSet: boolean;
        };
    }>;
}
