import { Observable } from 'rxjs';
import { SettingsService } from '../settings/settings.service';
import { Model } from 'mongoose';
import { OrderDocument } from './schemas/order.schema';
import { RecipeDocument } from '../recipes/schemas/recipe.schema';
import { UsersService } from '../users/users.service';
import { AuthService } from '../auth/auth.service';
import { CouponsService } from '../coupons/coupons.service';
export declare class OrdersService {
    private orderModel;
    private recipeModel;
    private settingsService;
    private usersService;
    private authService;
    private couponsService;
    private readonly logger;
    private orderEvents$;
    getOrderEvents(): Observable<{
        type: string;
        data: any;
    }>;
    emitOrderEvent(type: string, data: any): void;
    constructor(orderModel: Model<OrderDocument>, recipeModel: Model<RecipeDocument>, settingsService: SettingsService, usersService: UsersService, authService: AuthService, couponsService: CouponsService);
    createOrder(userId: string | undefined, orderData: any): Promise<any>;
    getUserOrders(userId: string, phone?: string): Promise<any[]>;
    trackOrder(identifier: string): Promise<any[]>;
    cancelOrderCustomer(orderId: string, reason: string): Promise<OrderDocument>;
    processRefund(id: string): Promise<OrderDocument>;
    getAllOrders(): Promise<any[]>;
    updateOrderStatus(orderId: string, status: string, preparationTime?: number, deliveryAgent?: {
        name: string;
        phone: string;
    }, cancelReason?: string): Promise<OrderDocument>;
    rateOrder(orderId: string, rating: number, review?: string): Promise<OrderDocument>;
    getRestaurantStats(): Promise<{
        averageRating: number;
        totalReviews: number;
    }>;
    generateInvoice(id: string): Promise<any>;
    requestCancel(id: string, reason: string): Promise<OrderDocument>;
    resolveCancelRequest(id: string, approve: boolean, processRefund?: boolean): Promise<OrderDocument>;
    requestReassign(id: string, reason: string, agentInfo?: {
        name: string;
        phone: string;
    }): Promise<OrderDocument>;
    resolveReassignRequest(id: string, approve: boolean, newAgent?: {
        name: string;
        phone: string;
    }): Promise<OrderDocument>;
}
