import { MessageEvent } from '@nestjs/common';
import { Observable } from 'rxjs';
import { Response } from 'express';
import { OrdersService } from './orders.service';
export declare class OrdersController {
    private readonly ordersService;
    constructor(ordersService: OrdersService);
    streamLiveOrders(): Observable<MessageEvent>;
    createOrder(req: any, orderData: any): Promise<any>;
    getUserOrders(req: any): Promise<any[]>;
    trackOrder(identifier: string): Promise<any[]>;
    cancelOrderCustomer(id: string, reason: string): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").Order, {}, {}> & import("./schemas/order.schema").Order & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    getRestaurantStats(): Promise<{
        averageRating: number;
        totalReviews: number;
    }>;
    rateOrder(id: string, rating: number, review: string): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").Order, {}, {}> & import("./schemas/order.schema").Order & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    getAllOrders(): Promise<any[]>;
    updateOrderStatus(id: string, status: string, preparationTime?: number, deliveryAgent?: {
        name: string;
        phone: string;
    }, cancelReason?: string): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").Order, {}, {}> & import("./schemas/order.schema").Order & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    downloadInvoice(id: string, res: Response): Promise<void>;
    requestCancel(id: string, reason: string): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").Order, {}, {}> & import("./schemas/order.schema").Order & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    resolveCancelRequest(id: string, approve: boolean, processRefund?: boolean): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").Order, {}, {}> & import("./schemas/order.schema").Order & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    processRefund(id: string): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").Order, {}, {}> & import("./schemas/order.schema").Order & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    requestReassign(id: string, reason: string, agentBody: any, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").Order, {}, {}> & import("./schemas/order.schema").Order & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    resolveReassignRequest(id: string, approve: boolean, newAgent?: {
        name: string;
        phone: string;
    }): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").Order, {}, {}> & import("./schemas/order.schema").Order & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}
