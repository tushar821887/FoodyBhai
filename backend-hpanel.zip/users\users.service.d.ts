import { Model } from 'mongoose';
import { UserDocument } from './schemas/user.schema';
export declare class UsersService {
    private userModel;
    private readonly logger;
    constructor(userModel: Model<UserDocument>);
    createUser(name: string, email: string, password: string, phone?: string, role?: string): Promise<UserDocument>;
    findByEmail(email: string): Promise<UserDocument | null>;
    findById(id: string): Promise<UserDocument | null>;
    validatePassword(plainPassword: string, hashedPassword: string): Promise<boolean>;
    findAll(): Promise<UserDocument[]>;
    updateUser(id: string, updateData: any): Promise<UserDocument | null>;
    deleteUser(id: string): Promise<any>;
    addAddress(userId: string, addressData: {
        label: string;
        fullAddress: string;
    }): Promise<UserDocument | null>;
    deleteAddress(userId: string, addressId: string): Promise<UserDocument | null>;
}
