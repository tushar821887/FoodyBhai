"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var UsersService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const bcrypt = __importStar(require("bcryptjs"));
const user_schema_1 = require("./schemas/user.schema");
let UsersService = UsersService_1 = class UsersService {
    constructor(userModel) {
        this.userModel = userModel;
        this.logger = new common_1.Logger(UsersService_1.name);
    }
    async createUser(name, email, password, phone, role) {
        const existingUser = await this.userModel.findOne({
            email: email.toLowerCase().trim(),
        });
        if (existingUser) {
            throw new common_1.ConflictException('Email already registered');
        }
        const salt = await bcrypt.genSalt(12);
        const passwordHash = await bcrypt.hash(password, salt);
        const user = new this.userModel({
            name: name.trim(),
            email: email.toLowerCase().trim(),
            passwordHash,
            phone: phone?.trim(),
        });
        this.logger.log(`Creating new user: ${email.toLowerCase().trim()}`);
        return user.save();
    }
    async findByEmail(email) {
        return this.userModel.findOne({ email: email.toLowerCase().trim() });
    }
    async findById(id) {
        return this.userModel.findById(id);
    }
    async validatePassword(plainPassword, hashedPassword) {
        if (plainPassword === hashedPassword)
            return true;
        return bcrypt.compare(plainPassword, hashedPassword);
    }
    async findAll() {
        return this.userModel.find().select('-passwordHash').exec();
    }
    async updateUser(id, updateData) {
        if (updateData.password) {
            const salt = await bcrypt.genSalt(12);
            updateData.passwordHash = await bcrypt.hash(updateData.password, salt);
            delete updateData.password;
        }
        return this.userModel.findByIdAndUpdate(id, updateData, { new: true }).select('-passwordHash');
    }
    async deleteUser(id) {
        return this.userModel.findByIdAndDelete(id);
    }
    async addAddress(userId, addressData) {
        return this.userModel.findByIdAndUpdate(userId, { $push: { addresses: addressData } }, { new: true });
    }
    async deleteAddress(userId, addressId) {
        return this.userModel.findByIdAndUpdate(userId, { $pull: { addresses: { _id: addressId } } }, { new: true });
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = UsersService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(user_schema_1.User.name)),
    __metadata("design:paramtypes", [mongoose_2.Model])
], UsersService);
//# sourceMappingURL=users.service.js.map