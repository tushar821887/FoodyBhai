import { HydratedDocument, Types } from 'mongoose';
export type OrderDocument = HydratedDocument<Order>;
declare class DeliveryDetails {
    name: string;
    phone: string;
    address: string;
}
declare class OrderItem {
    recipe: Record<string, any>;
    quantity: number;
}
export declare class Order {
    userId?: Types.ObjectId;
    items: OrderItem[];
    totalAmount: number;
    deliveryDetails: DeliveryDetails;
    status: string;
    preparationTime: number;
    paymentMethod: string;
    paymentStatus: string;
    orderType: string;
    deliveryAgent?: {
        name: string;
        phone: string;
    };
    itemTotal?: number;
    discount?: number;
    gst?: number;
    platformFee?: number;
    rating?: number;
    review?: string;
    refundStatus?: string;
    cancelRequest?: {
        requested: boolean;
        reason: string;
        status: string;
        requestedBy?: string;
    };
    reassignRequest?: {
        requested: boolean;
        reason: string;
        status: string;
        requestedByAgent?: {
            name: string;
            phone: string;
        };
        requestedAt?: Date;
        resolvedAt?: Date;
    };
    cancellationDetails?: {
        cancelledBy: string;
        reason?: string;
    };
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const OrderSchema: import("mongoose").Schema<Order, import("mongoose").Model<Order, any, any, any, import("mongoose").Document<unknown, any, Order, any, {}> & Order & {
    _id: Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Order, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Order>, {}, import("mongoose").DefaultSchemaOptions> & import("mongoose").FlatRecord<Order> & {
    _id: Types.ObjectId;
} & {
    __v: number;
}>;
export {};
