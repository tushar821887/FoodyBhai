"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecipesService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const recipe_schema_1 = require("./schemas/recipe.schema");
let RecipesService = class RecipesService {
    constructor(recipeModel) {
        this.recipeModel = recipeModel;
    }
    async findAll() {
        return this.recipeModel.find().exec();
    }
    async findBySlug(slug) {
        const recipe = await this.recipeModel.findOne({ slug }).exec();
        if (!recipe) {
            throw new common_1.NotFoundException(`Recipe with slug ${slug} not found`);
        }
        return recipe;
    }
    normalizeArrayField(val) {
        if (Array.isArray(val)) {
            return val.map((s) => String(s).trim()).filter((s) => s.length > 0);
        }
        if (typeof val === 'string') {
            return val.split('\n').map((s) => s.trim()).filter((s) => s.length > 0);
        }
        return [];
    }
    async create(recipeData) {
        if (!recipeData.id) {
            const highestRecipe = await this.recipeModel.findOne().sort('-id').exec();
            recipeData.id = highestRecipe && highestRecipe.id ? highestRecipe.id + 1 : 1;
        }
        if (!recipeData.slug && recipeData.title) {
            recipeData.slug = recipeData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
        }
        if (recipeData.ingredients !== undefined) {
            recipeData.ingredients = this.normalizeArrayField(recipeData.ingredients);
        }
        if (recipeData.instructions !== undefined) {
            recipeData.instructions = this.normalizeArrayField(recipeData.instructions);
        }
        if (recipeData.tips !== undefined) {
            recipeData.tips = this.normalizeArrayField(recipeData.tips);
        }
        const createdRecipe = new this.recipeModel(recipeData);
        return createdRecipe.save();
    }
    async update(id, updateData) {
        const filter = id.match(/^[0-9a-fA-F]{24}$/) ? { _id: id } : { id: Number(id) };
        if (updateData.ingredients !== undefined) {
            updateData.ingredients = this.normalizeArrayField(updateData.ingredients);
        }
        if (updateData.instructions !== undefined) {
            updateData.instructions = this.normalizeArrayField(updateData.instructions);
        }
        if (updateData.tips !== undefined) {
            updateData.tips = this.normalizeArrayField(updateData.tips);
        }
        const updatedRecipe = await this.recipeModel.findOneAndUpdate(filter, updateData, { new: true }).exec();
        if (!updatedRecipe) {
            throw new common_1.NotFoundException(`Recipe with id ${id} not found`);
        }
        return updatedRecipe;
    }
    async remove(id) {
        const filter = id.match(/^[0-9a-fA-F]{24}$/) ? { _id: id } : { id: Number(id) };
        const result = await this.recipeModel.deleteOne(filter).exec();
        if (result.deletedCount === 0) {
            throw new common_1.NotFoundException(`Recipe with id ${id} not found`);
        }
        return { success: true, message: 'Recipe deleted' };
    }
};
exports.RecipesService = RecipesService;
exports.RecipesService = RecipesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(recipe_schema_1.Recipe.name)),
    __metadata("design:paramtypes", [mongoose_2.Model])
], RecipesService);
//# sourceMappingURL=recipes.service.js.map