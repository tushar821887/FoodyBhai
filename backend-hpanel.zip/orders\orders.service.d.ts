import { Observable } from 'rxjs';
import { SettingsService } from '../settings/settings.service';
import { Model } from 'mongoose';
import { OrderDocument } from './schemas/order.schema';
export declare class OrdersService {
    private orderModel;
    private settingsService;
    private orderEvents$;
    getOrderEvents(): Observable<{
        type: string;
        data: any;
    }>;
    emitOrderEvent(type: string, data: any): void;
    constructor(orderModel: Model<OrderDocument>, settingsService: SettingsService);
    createOrder(userId: string, orderData: any): Promise<OrderDocument>;
    getUserOrders(userId: string, phone?: string): Promise<OrderDocument[]>;
    cancelOrderCustomer(orderId: string, reason: string): Promise<OrderDocument>;
    processRefund(id: string): Promise<OrderDocument>;
    getAllOrders(): Promise<OrderDocument[]>;
    updateOrderStatus(orderId: string, status: string, preparationTime?: number, deliveryAgent?: {
        name: string;
        phone: string;
    }, cancelReason?: string): Promise<OrderDocument>;
    rateOrder(orderId: string, rating: number, review?: string): Promise<OrderDocument>;
    getRestaurantStats(): Promise<{
        averageRating: number;
        totalReviews: number;
    }>;
    generateInvoice(id: string): Promise<any>;
    requestCancel(id: string, reason: string): Promise<OrderDocument>;
    resolveCancelRequest(id: string, approve: boolean, processRefund?: boolean): Promise<OrderDocument>;
    requestReassign(id: string, reason: string, agentInfo?: {
        name: string;
        phone: string;
    }): Promise<OrderDocument>;
    resolveReassignRequest(id: string, approve: boolean, newAgent?: {
        name: string;
        phone: string;
    }): Promise<OrderDocument>;
}
