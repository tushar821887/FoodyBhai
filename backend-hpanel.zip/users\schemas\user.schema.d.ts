import { HydratedDocument } from 'mongoose';
export type UserDocument = HydratedDocument<User>;
export declare class Address {
    label: string;
    fullAddress: string;
}
export declare class User {
    name: string;
    email: string;
    phone: string;
    passwordHash: string;
    role: string;
    dateOfBirth: string;
    gender: string;
    addresses: Address[];
}
export declare const UserSchema: import("mongoose").Schema<User, import("mongoose").Model<User, any, any, any, import("mongoose").Document<unknown, any, User, any, {}> & User & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, User, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<User>, {}, import("mongoose").DefaultSchemaOptions> & import("mongoose").FlatRecord<User> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
