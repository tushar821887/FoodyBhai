import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../users/users.service';
import { AgentsService } from '../agents/agents.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
export declare class AuthService {
    private readonly usersService;
    private readonly agentsService;
    private readonly jwtService;
    private readonly logger;
    constructor(usersService: UsersService, agentsService: AgentsService, jwtService: JwtService);
    register(registerDto: RegisterDto): Promise<{
        success: boolean;
        message: string;
        user: {
            id: string;
            name: string;
            email: string;
            role: string;
        };
    }>;
    login(loginDto: LoginDto): Promise<{
        success: boolean;
        message: string;
        accessToken: string;
        user: {
            id: string | null;
            name: string | null;
            email: string;
            role: string | null;
            phone: string | null;
        };
    }>;
}
