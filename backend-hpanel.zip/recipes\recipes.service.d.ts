import { Model } from 'mongoose';
import { RecipeDocument } from './schemas/recipe.schema';
export declare class RecipesService {
    private recipeModel;
    constructor(recipeModel: Model<RecipeDocument>);
    findAll(): Promise<RecipeDocument[]>;
    findBySlug(slug: string): Promise<RecipeDocument>;
    private normalizeArrayField;
    create(recipeData: any): Promise<RecipeDocument>;
    update(id: string, updateData: any): Promise<RecipeDocument>;
    remove(id: string): Promise<any>;
}
