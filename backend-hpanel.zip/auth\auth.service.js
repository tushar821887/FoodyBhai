"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AuthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const users_service_1 = require("../users/users.service");
const agents_service_1 = require("../agents/agents.service");
const bcrypt = __importStar(require("bcryptjs"));
let AuthService = AuthService_1 = class AuthService {
    constructor(usersService, agentsService, jwtService) {
        this.usersService = usersService;
        this.agentsService = agentsService;
        this.jwtService = jwtService;
        this.logger = new common_1.Logger(AuthService_1.name);
    }
    async register(registerDto) {
        const user = await this.usersService.createUser(registerDto.name, registerDto.email, registerDto.password, registerDto.phone);
        this.logger.log(`User registered: ${user.email}`);
        return {
            success: true,
            message: 'Registration successful',
            user: {
                id: user._id.toString(),
                name: user.name,
                email: user.email,
                role: user.role,
            },
        };
    }
    async login(loginDto) {
        loginDto.email = loginDto.email.toLowerCase().trim();
        let user = await this.usersService.findByEmail(loginDto.email);
        let role = user ? user.role : null;
        let passwordHash = user ? user.passwordHash : null;
        let userId = user ? user._id.toString() : null;
        let name = user ? user.name : null;
        let phone = user ? user.phone : null;
        if (!user) {
            const agent = await this.agentsService.findByEmail(loginDto.email);
            if (agent) {
                role = 'agent';
                passwordHash = agent.passwordHash || '';
                userId = agent._id.toString();
                name = agent.name;
                phone = agent.phone;
                user = agent;
            }
        }
        if (!user) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        let isPasswordValid = false;
        if (passwordHash && !passwordHash.startsWith('$2')) {
            isPasswordValid = (loginDto.password === passwordHash);
        }
        else {
            isPasswordValid = await bcrypt.compare(loginDto.password, passwordHash || '');
        }
        if (!isPasswordValid) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        const payload = {
            sub: userId,
            email: loginDto.email,
            role: role,
        };
        const accessToken = this.jwtService.sign(payload);
        this.logger.log(`User logged in: ${loginDto.email}`);
        return {
            success: true,
            message: 'Login successful',
            accessToken,
            user: {
                id: userId,
                name: name,
                email: loginDto.email,
                role: role,
                phone: phone,
            },
        };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = AuthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [users_service_1.UsersService,
        agents_service_1.AgentsService,
        jwt_1.JwtService])
], AuthService);
//# sourceMappingURL=auth.service.js.map