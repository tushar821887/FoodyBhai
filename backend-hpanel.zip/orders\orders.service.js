"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersService = void 0;
const PDFDocument = require('pdfkit');
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const settings_service_1 = require("../settings/settings.service");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const order_schema_1 = require("./schemas/order.schema");
let OrdersService = class OrdersService {
    getOrderEvents() {
        return this.orderEvents$.asObservable();
    }
    emitOrderEvent(type, data) {
        try {
            this.orderEvents$.next({ type, data });
        }
        catch (err) {
            console.error('Failed to emit order event:', err);
        }
    }
    constructor(orderModel, settingsService) {
        this.orderModel = orderModel;
        this.settingsService = settingsService;
        this.orderEvents$ = new rxjs_1.Subject();
    }
    async createOrder(userId, orderData) {
        const isOnline = await this.settingsService.getSetting('restaurant_open');
        if (isOnline && (isOnline.value === 'false' || isOnline.value === false)) {
            throw new common_1.BadRequestException('We are currently offline and not accepting orders.');
        }
        const order = new this.orderModel({
            userId,
            ...orderData
        });
        const saved = await order.save();
        this.emitOrderEvent('new_order', saved);
        return saved;
    }
    async getUserOrders(userId, phone) {
        const query = { $or: [{ userId }] };
        if (phone) {
            query.$or.push({ 'deliveryDetails.phone': phone });
        }
        return this.orderModel.find(query).sort({ createdAt: -1 }).exec();
    }
    async cancelOrderCustomer(orderId, reason) {
        const existingOrder = await this.orderModel.findById(orderId);
        if (!existingOrder)
            throw new common_1.NotFoundException('Order not found');
        const orderDate = new Date(existingOrder.createdAt || Date.now()).getTime();
        const now = new Date().getTime();
        const diffMinutes = (now - orderDate) / (1000 * 60);
        if (diffMinutes > 1) {
            throw new common_1.BadRequestException('Cannot cancel order after 1 minute. Please contact support.');
        }
        const order = await this.orderModel.findByIdAndUpdate(orderId, {
            $set: {
                cancelRequest: {
                    requested: true,
                    reason: reason || 'Customer requested cancellation',
                    status: 'pending',
                    requestedBy: 'Customer'
                }
            }
        }, { new: true }).exec();
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        this.emitOrderEvent('cancel_requested', order);
        return order;
    }
    async processRefund(id) {
        const order = await this.orderModel.findByIdAndUpdate(id, { $set: { refundStatus: 'completed' } }, { new: true });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        return order;
    }
    async getAllOrders() {
        return this.orderModel.find().populate('userId', 'name email phone').sort({ createdAt: -1 }).exec();
    }
    async updateOrderStatus(orderId, status, preparationTime, deliveryAgent, cancelReason) {
        const existingOrder = await this.orderModel.findById(orderId);
        if (!existingOrder)
            throw new common_1.NotFoundException('Order not found');
        const updateData = { status };
        if (status === 'delivered') {
            updateData.paymentStatus = 'paid';
        }
        else if (status === 'preparing' && existingOrder.paymentMethod === 'online') {
            updateData.paymentStatus = 'paid';
        }
        if (status === 'cancelled' || status === 'rejected') {
            updateData.cancellationDetails = { cancelledBy: 'Restaurant' };
            if (cancelReason)
                updateData.cancellationDetails.reason = cancelReason;
            if (existingOrder.paymentMethod === 'online') {
                updateData.refundStatus = 'pending';
            }
        }
        if (preparationTime !== undefined) {
            updateData.preparationTime = preparationTime;
        }
        if (deliveryAgent) {
            updateData.deliveryAgent = deliveryAgent;
            if (existingOrder.reassignRequest && existingOrder.reassignRequest.status === 'pending') {
                updateData['reassignRequest.status'] = 'approved';
                updateData['reassignRequest.resolvedAt'] = new Date();
            }
        }
        const order = await this.orderModel.findByIdAndUpdate(orderId, { $set: updateData }, { new: true });
        if (!order) {
            throw new common_1.NotFoundException('Order not found');
        }
        this.emitOrderEvent('status_updated', order);
        return order;
    }
    async rateOrder(orderId, rating, review) {
        const order = await this.orderModel.findByIdAndUpdate(orderId, { $set: { rating, review } }, { new: true });
        if (!order) {
            throw new common_1.NotFoundException('Order not found');
        }
        return order;
    }
    async getRestaurantStats() {
        const ordersWithRatings = await this.orderModel.find({ rating: { $exists: true, $ne: null } }).exec();
        const totalRatings = ordersWithRatings.length;
        const avgRating = totalRatings > 0
            ? (ordersWithRatings.reduce((sum, order) => sum + (order.rating || 0), 0) / totalRatings).toFixed(1)
            : 0;
        return {
            averageRating: parseFloat(avgRating),
            totalReviews: totalRatings
        };
    }
    async generateInvoice(id) {
        const order = await this.orderModel.findById(id).populate('items.recipe').exec();
        if (!order) {
            throw new common_1.NotFoundException('Order not found');
        }
        const doc = new PDFDocument({ margin: 50 });
        doc.fontSize(20).text('FOODY BHAI', { align: 'center' });
        doc.fontSize(10).text('127, Bhatwara, Meerut - 250002', { align: 'center' });
        doc.text('+91 8218870579 | support@foodybhai.com', { align: 'center' });
        doc.moveDown();
        doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown();
        doc.fontSize(14).text('TAX INVOICE', { align: 'center' }).moveDown();
        doc.fontSize(10);
        doc.text(`Order ID: ${order._id.toString().slice(-6).toUpperCase()}`);
        doc.text(`Date: ${order.createdAt ? new Date(order.createdAt).toLocaleString() : new Date().toLocaleString()}`);
        doc.text(`Status: ${order.status.toUpperCase()}`);
        doc.moveDown();
        doc.text('Billed To:');
        doc.text(order.deliveryDetails.name);
        doc.text(order.deliveryDetails.phone);
        doc.text(order.deliveryDetails.address);
        doc.moveDown();
        doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(0.5);
        const tableTop = doc.y;
        doc.text('Item', 50, tableTop, { width: 250 });
        doc.text('Qty', 300, tableTop, { width: 50, align: 'center' });
        doc.text('Price', 350, tableTop, { width: 100, align: 'right' });
        doc.text('Total', 450, tableTop, { width: 100, align: 'right' });
        doc.moveDown(0.5);
        doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(0.5);
        let subtotal = 0;
        order.items.forEach(item => {
            const y = doc.y;
            const title = item.recipe ? item.recipe.title : 'Unknown Item';
            const price = item.recipe ? item.recipe.price : 0;
            const qty = item.quantity;
            const total = price * qty;
            subtotal += total;
            doc.text(title, 50, y, { width: 250 });
            doc.text(qty.toString(), 300, y, { width: 50, align: 'center' });
            doc.text(`Rs. ${price}`, 350, y, { width: 100, align: 'right' });
            doc.text(`Rs. ${total}`, 450, y, { width: 100, align: 'right' });
            doc.moveDown();
        });
        doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown();
        const gst = order.gst || (subtotal * 0.05);
        const platformFee = order.platformFee || 5;
        const finalTotal = subtotal + gst + platformFee;
        doc.text(`Subtotal:`, 350, doc.y, { width: 100, align: 'right' });
        doc.text(`Rs. ${subtotal.toFixed(2)}`, 450, doc.y, { width: 100, align: 'right' }).moveDown(0.5);
        doc.text(`GST (5%):`, 350, doc.y, { width: 100, align: 'right' });
        doc.text(`Rs. ${gst.toFixed(2)}`, 450, doc.y, { width: 100, align: 'right' }).moveDown(0.5);
        doc.text(`Platform Fee:`, 350, doc.y, { width: 100, align: 'right' });
        doc.text(`Rs. ${platformFee.toFixed(2)}`, 450, doc.y, { width: 100, align: 'right' }).moveDown(0.5);
        doc.moveTo(350, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(0.5);
        doc.fontSize(12).font('Helvetica-Bold');
        doc.text(`Total Amount:`, 350, doc.y, { width: 100, align: 'right' });
        doc.text(`Rs. ${finalTotal.toFixed(2)}`, 450, doc.y, { width: 100, align: 'right' });
        doc.font('Helvetica');
        doc.moveDown(3);
        doc.fontSize(10).text('Thank you for ordering from Foody Bhai!', { align: 'center', color: 'grey' });
        doc.end();
        return doc;
    }
    async requestCancel(id, reason) {
        const order = await this.orderModel.findByIdAndUpdate(id, {
            $set: {
                cancelRequest: {
                    requested: true,
                    reason,
                    status: 'pending'
                }
            }
        }, { new: true });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        return order;
    }
    async resolveCancelRequest(id, approve, processRefund = false) {
        const existingOrder = await this.orderModel.findById(id);
        if (!existingOrder)
            throw new common_1.NotFoundException('Order not found');
        const updateData = {
            $set: {
                'cancelRequest.status': approve ? 'approved' : 'rejected'
            }
        };
        if (approve) {
            updateData.$set.status = 'cancelled';
            updateData.$set.cancellationDetails = {
                cancelledBy: existingOrder.cancelRequest?.requestedBy || 'Delivery Agent',
                reason: existingOrder.cancelRequest?.reason
            };
            if (existingOrder.paymentMethod === 'online') {
                updateData.$set.refundStatus = processRefund ? 'completed' : 'pending';
            }
        }
        const order = await this.orderModel.findByIdAndUpdate(id, updateData, { new: true });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        return order;
    }
    async requestReassign(id, reason, agentInfo) {
        const existingOrder = await this.orderModel.findById(id);
        if (!existingOrder)
            throw new common_1.NotFoundException('Order not found');
        const agent = (agentInfo && agentInfo.phone) ? agentInfo : existingOrder.deliveryAgent;
        const order = await this.orderModel.findByIdAndUpdate(id, {
            $set: {
                reassignRequest: {
                    requested: true,
                    reason,
                    status: 'pending',
                    requestedByAgent: agent,
                    requestedAt: new Date()
                }
            }
        }, { new: true });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        this.emitOrderEvent('reassign_requested', order);
        return order;
    }
    async resolveReassignRequest(id, approve, newAgent) {
        const existingOrder = await this.orderModel.findById(id);
        if (!existingOrder)
            throw new common_1.NotFoundException('Order not found');
        const updateData = {
            $set: {
                'reassignRequest.status': approve ? 'approved' : 'rejected',
                'reassignRequest.resolvedAt': new Date()
            }
        };
        if (approve && newAgent) {
            updateData.$set.deliveryAgent = newAgent;
        }
        const order = await this.orderModel.findByIdAndUpdate(id, updateData, { new: true });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        this.emitOrderEvent('reassign_resolved', order);
        return order;
    }
};
exports.OrdersService = OrdersService;
exports.OrdersService = OrdersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(order_schema_1.Order.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        settings_service_1.SettingsService])
], OrdersService);
//# sourceMappingURL=orders.service.js.map