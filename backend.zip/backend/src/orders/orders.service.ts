const PDFDocument = require('pdfkit');
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { Subject, Observable } from 'rxjs';
import { SettingsService } from '../settings/settings.service';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Order, OrderDocument } from './schemas/order.schema';

@Injectable()
export class OrdersService {
  private orderEvents$ = new Subject<{ type: string; data: any }>();

  getOrderEvents(): Observable<{ type: string; data: any }> {
    return this.orderEvents$.asObservable();
  }

  emitOrderEvent(type: string, data: any) {
    try {
      this.orderEvents$.next({ type, data });
    } catch (err) {
      console.error('Failed to emit order event:', err);
    }
  }

  constructor(
    @InjectModel(Order.name) private orderModel: Model<OrderDocument>,
    private settingsService: SettingsService
  ) {}

  async createOrder(userId: string, orderData: any): Promise<OrderDocument> {
    const isOnline = await this.settingsService.getSetting('restaurant_open');
    if (isOnline && (isOnline.value === 'false' || isOnline.value === false)) {
      throw new BadRequestException('We are currently offline and not accepting orders.');
    }
    const order = new this.orderModel({
      userId,
      ...orderData
    });
    const saved = await order.save();
    this.emitOrderEvent('new_order', saved);
    return saved;
  }

  async getUserOrders(userId: string, phone?: string): Promise<OrderDocument[]> {
    const query: any = { $or: [{ userId }] };
    if (phone) {
      query.$or.push({ 'deliveryDetails.phone': phone });
    }
    return this.orderModel.find(query).sort({ createdAt: -1 }).exec();
  }

  async cancelOrderCustomer(orderId: string, reason: string): Promise<OrderDocument> {
    const existingOrder = await this.orderModel.findById(orderId);
    if (!existingOrder) throw new NotFoundException('Order not found');

    const orderDate = new Date(existingOrder.createdAt || Date.now()).getTime();
    const now = new Date().getTime();
    const diffMinutes = (now - orderDate) / (1000 * 60);

    if (diffMinutes > 1) {
      throw new BadRequestException('Cannot cancel order after 1 minute. Please contact support.');
    }

    // Always create a cancellation request instead of cancelling immediately
    const order = await this.orderModel.findByIdAndUpdate(
      orderId,
      {
        $set: {
          cancelRequest: {
            requested: true,
            reason: reason || 'Customer requested cancellation',
            status: 'pending',
            requestedBy: 'Customer'
          }
        }
      },
      { new: true }
    ).exec();
    if (!order) throw new NotFoundException('Order not found');
    this.emitOrderEvent('cancel_requested', order);
    return order;
  }

  async processRefund(id: string): Promise<OrderDocument> {
    const order = await this.orderModel.findByIdAndUpdate(
      id,
      { $set: { refundStatus: 'completed' } },
      { new: true }
    );
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }


  async getAllOrders(): Promise<OrderDocument[]> {
    // Sort by newest first
    return this.orderModel.find().populate('userId', 'name email phone').sort({ createdAt: -1 }).exec();
  }

  async updateOrderStatus(orderId: string, status: string, preparationTime?: number, deliveryAgent?: { name: string; phone: string }, cancelReason?: string): Promise<OrderDocument> {
    const existingOrder = await this.orderModel.findById(orderId);
    if (!existingOrder) throw new NotFoundException('Order not found');

    const updateData: any = { status };
    if (status === 'delivered') {
      updateData.paymentStatus = 'paid';
    } else if (status === 'preparing' && existingOrder.paymentMethod === 'online') {
      updateData.paymentStatus = 'paid';
    }
    if (status === 'cancelled' || status === 'rejected') {
      updateData.cancellationDetails = { cancelledBy: 'Restaurant' };
      if (cancelReason) updateData.cancellationDetails.reason = cancelReason;
      if (existingOrder.paymentMethod === 'online') {
        updateData.refundStatus = 'pending';
      }
    }
    if (preparationTime !== undefined) {
      updateData.preparationTime = preparationTime;
    }
    if (deliveryAgent) {
      updateData.deliveryAgent = deliveryAgent;
      if (existingOrder.reassignRequest && existingOrder.reassignRequest.status === 'pending') {
        updateData['reassignRequest.status'] = 'approved';
        updateData['reassignRequest.resolvedAt'] = new Date();
      }
    }

    const order = await this.orderModel.findByIdAndUpdate(
      orderId,
      { $set: updateData },
      { new: true }
    );

    if (!order) {
      throw new NotFoundException('Order not found');
    }
    this.emitOrderEvent('status_updated', order);
    return order;
  }

  async rateOrder(orderId: string, rating: number, review?: string): Promise<OrderDocument> {
    const order = await this.orderModel.findByIdAndUpdate(
      orderId,
      { $set: { rating, review } },
      { new: true }
    );
    if (!order) {
      throw new NotFoundException('Order not found');
    }
    return order;
  }
  async getRestaurantStats() {
    const ordersWithRatings = await this.orderModel.find({ rating: { $exists: true, $ne: null } }).exec();
    const totalRatings = ordersWithRatings.length;
    const avgRating = totalRatings > 0 
      ? (ordersWithRatings.reduce((sum, order) => sum + (order.rating || 0), 0) / totalRatings).toFixed(1)
      : 0;
      
    return {
      averageRating: parseFloat(avgRating as string),
      totalReviews: totalRatings
    };
  }

  async generateInvoice(id: string): Promise<any> {
    const order = await this.orderModel.findById(id).populate('items.recipe').exec();
    if (!order) {
      throw new NotFoundException('Order not found');
    }

    const doc = new PDFDocument({ margin: 50 });
    
    // Header
    doc.fontSize(20).text('FOODY BHAI', { align: 'center' });
    doc.fontSize(10).text('127, Bhatwara, Meerut - 250002', { align: 'center' });
    doc.text('+91 8218870579 | support@foodybhai.com', { align: 'center' });
    doc.moveDown();
    doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown();

    // Order Info
    doc.fontSize(14).text('TAX INVOICE', { align: 'center' }).moveDown();
    doc.fontSize(10);
    doc.text(`Order ID: ${order._id.toString().slice(-6).toUpperCase()}`);
    doc.text(`Date: ${(order as any).createdAt ? new Date((order as any).createdAt).toLocaleString() : new Date().toLocaleString()}`);
    doc.text(`Status: ${order.status.toUpperCase()}`);
    doc.moveDown();

    // Customer Info
    doc.text('Billed To:');
    doc.text(order.deliveryDetails.name);
    doc.text(order.deliveryDetails.phone);
    doc.text(order.deliveryDetails.address);
    doc.moveDown();

    // Items Table Header
    doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown(0.5);
    const tableTop = doc.y;
    doc.text('Item', 50, tableTop, { width: 250 });
    doc.text('Qty', 300, tableTop, { width: 50, align: 'center' });
    doc.text('Price', 350, tableTop, { width: 100, align: 'right' });
    doc.text('Total', 450, tableTop, { width: 100, align: 'right' });
    doc.moveDown(0.5);
    doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown(0.5);

    // Items
    let subtotal = 0;
    order.items.forEach(item => {
      const y = doc.y;
      const title = item.recipe ? (item.recipe as any).title : 'Unknown Item';
      const price = item.recipe ? (item.recipe as any).price : 0;
      const qty = item.quantity;
      const total = price * qty;
      subtotal += total;

      doc.text(title, 50, y, { width: 250 });
      doc.text(qty.toString(), 300, y, { width: 50, align: 'center' });
      doc.text(`Rs. ${price}`, 350, y, { width: 100, align: 'right' });
      doc.text(`Rs. ${total}`, 450, y, { width: 100, align: 'right' });
      doc.moveDown();
    });

    doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown();

    // Summary
    const gst = order.gst || (subtotal * 0.05);
    const platformFee = order.platformFee || 5;
    const finalTotal = subtotal + gst + platformFee;

    doc.text(`Subtotal:`, 350, doc.y, { width: 100, align: 'right' });
    doc.text(`Rs. ${subtotal.toFixed(2)}`, 450, doc.y, { width: 100, align: 'right' }).moveDown(0.5);
    
    doc.text(`GST (5%):`, 350, doc.y, { width: 100, align: 'right' });
    doc.text(`Rs. ${gst.toFixed(2)}`, 450, doc.y, { width: 100, align: 'right' }).moveDown(0.5);
    
    doc.text(`Platform Fee:`, 350, doc.y, { width: 100, align: 'right' });
    doc.text(`Rs. ${platformFee.toFixed(2)}`, 450, doc.y, { width: 100, align: 'right' }).moveDown(0.5);

    doc.moveTo(350, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown(0.5);

    doc.fontSize(12).font('Helvetica-Bold');
    doc.text(`Total Amount:`, 350, doc.y, { width: 100, align: 'right' });
    doc.text(`Rs. ${finalTotal.toFixed(2)}`, 450, doc.y, { width: 100, align: 'right' });
    doc.font('Helvetica');

    doc.moveDown(3);
    doc.fontSize(10).text('Thank you for ordering from Foody Bhai!', { align: 'center', color: 'grey' });

    doc.end();
    return doc;
  }

  async requestCancel(id: string, reason: string): Promise<OrderDocument> {
    const order = await this.orderModel.findByIdAndUpdate(
      id,
      {
        $set: {
          cancelRequest: {
            requested: true,
            reason,
            status: 'pending'
          }
        }
      },
      { new: true }
    );
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }

  async resolveCancelRequest(id: string, approve: boolean, processRefund: boolean = false): Promise<OrderDocument> {
    const existingOrder = await this.orderModel.findById(id);
    if (!existingOrder) throw new NotFoundException('Order not found');
    const updateData: any = {
      $set: {
        'cancelRequest.status': approve ? 'approved' : 'rejected'
      }
    };
    if (approve) {
      updateData.$set.status = 'cancelled';
      updateData.$set.cancellationDetails = { 
        cancelledBy: existingOrder.cancelRequest?.requestedBy || 'Delivery Agent', 
        reason: existingOrder.cancelRequest?.reason 
      };
      if (existingOrder.paymentMethod === 'online') {
        updateData.$set.refundStatus = processRefund ? 'completed' : 'pending';
      }
    }
    const order = await this.orderModel.findByIdAndUpdate(
      id,
      updateData,
      { new: true }
    );
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }

  async requestReassign(id: string, reason: string, agentInfo?: { name: string; phone: string }): Promise<OrderDocument> {
    const existingOrder = await this.orderModel.findById(id);
    if (!existingOrder) throw new NotFoundException('Order not found');

    const agent = (agentInfo && agentInfo.phone) ? agentInfo : existingOrder.deliveryAgent;

    const order = await this.orderModel.findByIdAndUpdate(
      id,
      {
        $set: {
          reassignRequest: {
            requested: true,
            reason,
            status: 'pending',
            requestedByAgent: agent,
            requestedAt: new Date()
          }
        }
      },
      { new: true }
    );
    if (!order) throw new NotFoundException('Order not found');
    this.emitOrderEvent('reassign_requested', order);
    return order;
  }

  async resolveReassignRequest(id: string, approve: boolean, newAgent?: { name: string; phone: string }): Promise<OrderDocument> {
    const existingOrder = await this.orderModel.findById(id);
    if (!existingOrder) throw new NotFoundException('Order not found');

    const updateData: any = {
      $set: {
        'reassignRequest.status': approve ? 'approved' : 'rejected',
        'reassignRequest.resolvedAt': new Date()
      }
    };

    if (approve && newAgent) {
      updateData.$set.deliveryAgent = newAgent;
    }

    const order = await this.orderModel.findByIdAndUpdate(
      id,
      updateData,
      { new: true }
    );
    if (!order) throw new NotFoundException('Order not found');
    this.emitOrderEvent('reassign_resolved', order);
    return order;
  }
}